<html>
<head>
<link rel="stylesheet" type="text/css" href="check_statuscss.css">
<style>
p{
	color:#2E2E2E;
	font-size:30px;
}
</style>
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
<a href="home_html.html" style="color:red;font-size:40px;margin-left:90%;">logout</a>
</center>
<div id="div2">
<div id="div3">
</div>
<div id="div4">
<center>
<div id="div5">
<form action="update_smcr.php" method="post">
<table>
<center>
<tr>
<td><label id=l1>Complaint id: </label></td>
<td><input type="text" placeholder="Enter complaint id" id="cid" name="cid"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td><label id=l1>Complaint status: </label></td>
<td><input type="text" placeholder="Enter complaint status" id="cid" name="status"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td colspan="2" rowspan="2" align="center"><button type="submit" id="getstatus">Update</button></td>
</tr>
</center>
</table>
</table>
</form>
</div>
</center>
</div>
</div>
</body>
</html>