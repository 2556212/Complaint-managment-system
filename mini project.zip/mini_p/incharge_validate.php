<?php
                      $username= $_POST['uname'];
	$password= $_POST['pass'];
	if($username=="incharge"&&$password=="cms")
	header("Location: incharge.html");
	else
	{
	header("Location: incharge_login.php");
                     echo 'invalid';
	}
	
?>
  