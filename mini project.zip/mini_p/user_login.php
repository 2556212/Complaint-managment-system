<html>
<head>
<title>
login form</title>
<style>
table{
border:none;
margin-top:130px;
color:#2E2E2E;
}
a{
font-size:40px;
}
td{
font-size:30px;
}
#but1{
font-size:30px;
width:100;
height:40;
background-color:#4B8A08;
color:white;
}
h1{
font-size:40px;
margin:30px;
color:#FF00BF;
text-decoration:underline;
}
a{
color:#2E2E2E;
}
.row{
height:30px;
width:200px;
border-radius:3px;
}
body{
background-image:url("bg9.jpg");
background-repeat:no-repeat;
background-attachment:fixed;
width:100%;
height:100%;
font-family:calibri;
font-size: 40px;
}
</style>
</head>
<body>
<center>
<h1>Login Here</h1>
<form action="validate2.php" method="post">
<table border=0px cellspacing=0 cellpadding=0>
<tr>
<td>Username: </td>
<td><input type="text" name="uname" class="row" placeholder="Enter username"></td>
<tr><td>&nbsp;</td></tr>
<td>Password: </td>
<td><input type="password" name="pass" class="row" placeholder="Enter password"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td colspan="2" rowspan="2" align="center"><button type="submit" name="submit" id="but1">submit</button></td>
</tr>
</table>
</form></br>
New User?<a href="user_register.php"> Register Here</a>
</center>
</body>
</html>