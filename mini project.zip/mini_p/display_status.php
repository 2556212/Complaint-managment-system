<?php
	$connect=new mysqli('localhost','root','','cms');
	if($connect->connect_error){
	echo("connection failed");
	}else
	{
	$cid=$_POST['cid'];
	$sql="select  status from smcr3 where id='$cid'";
	$result=$connect->query($sql);
	if($result->num_rows>0){
		$row=mysqli_fetch_array($result);
		$ans=$row['status'];
	}
	else
		header("Location: check_status1.php");
	}
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="about_css.css">
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
<a href="home_html.html" style="color:red;font-size:40px;margin-left:90%;">logout</a>
<p>welcome!  your complaint is
<?php echo $ans; ?>,Thank you!</p>
</center> 
</body>
</html>
  