<?php
	$username=$_POST['uname'];
	$password=$_POST['pass'];

	mysql_connect("localhost","root","");
	mysql_select_db("cms");

	$result=mysql_query("select * from user_login where username='$username' and password='$password'") or die("Failed to query database".mysql_error());
	$row=mysql_fetch_array($result);
	if($row['username']==$username && $row['password']==$password){
		echo "Login success";
	}
	else{
		echo "failed to login";
		}
?>