<?php
	$con=mysqli_connect('localhost','root','');
	if(!$con)
	{
	echo 'not connected';
	}
	if(!mysqli_select_db($con,'cms'))
	{
	echo 'database not selected';
	}
	$username=$_POST['uname'];
	$branch=$_POST['branch'];
	$issue=$_POST['complaint'];
	$status="pending";
	$incharge="OA, CSE/Sr CSE ";
	$sql="INSERT INTO reg1 (username,issue,branch,incharge,date_of_registration,status) VALUES ('$username','$issue','$branch','$incharge',CURDATE(),'$status')";
	if(mysqli_query($con,$sql))
	{
		$id1=mysqli_insert_id($con);
	}
	else{
		echo "Not inserted";
	}
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="about_css.css">
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
<p>Thank you! Your complaint has been Registered and we will look after into it.</p>
<p>Your complaint id is
<?php echo $id1; ?>.</p>
<p>You may note down this complaint id for further reference</p>
</center> 
</body>
</html>