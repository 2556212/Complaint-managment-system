<?php
              session_start();
              $con=mysqli_connect('localhost','root','');
              mysqli_select_db($con,'cms');
              $username=$_POST['uname'];
             $branch=$_POST['branch'];
             $issue=$_POST['complaint'];
              $status="pending";
              $incharge="OA, CSE/Sr CSE ";
              $sql1="insert into ocr3 (Username,Issue,branch,Incharge,date_of_registration,status)
                                 values('$username','$issue','$branch','$incharge',curdate(),'$status')";
	mysqli_query($con,$sql1);
              $reg="insert into smcr3(Username,Issue,Branch,Incharge,date_of_registration,status) 
                  values('$username','$issue','$branch','$incharge',curdate(),'$status')";
              $result = mysqli_query($con, $reg);
              
    
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="about_css.css">
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
<a href="home_html.html" style="color:red;font-size:40px;margin-left:90%;">logout</a>
<p>Thank you! Your complaint has been Registered and we will look after into it.</p>
<p>Your complaint id is
<?php

   

    $con=mysqli_connect('localhost','root','');

    mysqli_select_db($con,'cms');
    
    $s =  "select * from smcr3 where Username='$username'";

    $sql = mysqli_query($con, $s);

    $row = mysqli_fetch_assoc($sql);

   $id = $row['id'];
?>

<?php echo $id; ?>.</p>
<p>You may note down this complaint id for further reference</p>
</center> 
</body>
</html>


