<?php
	$con=mysqli_connect('localhost','root','');
	if(!$con)
	{
	echo 'not connected';
	}
	if(!mysqli_select_db($con,'cms'))
	{
	echo 'database not selected';
	}
	$id1=mysqli_insert_id($con);
	header("Location: uniq_id1.html");
	echo "Not inserted";
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="about_css.css">
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
</center>
<div id="div2">
<div id="div3">
</div>
<div id="div4">
<center>
<div id="div5">
<?php 
echo "the id is:"; 
echo '$id1';
?>
<p>Still any queries?Contact us</p>
<p>id is</p>
<p>Mail id:CMSinfo@gmail.com</p>
</div>
</center>
</div>
</div>
</body>
</html>