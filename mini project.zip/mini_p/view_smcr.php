<?php
	$connect=new mysqli('localhost','root','','cms');
	if($connect->connect_error){
	echo("connection failed");
	}
	$sql = "SELECT * FROM smcr3";
	$result = $connect->query($sql);
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="help_css.css">
<style>
td{
	color:#2E2E2E;
	font-size:20px;
}
h1{
	color:#2E2E2E;
}
</style>
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
</center>
<a href="home_html.html" style="color:red;font-size:40px;margin-left:90%;">logout</a>
<h1 align="center">SELCO Master Complaints  Register</h1>
<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Complaint ID</th>
<th>username</th>
<th>Issue</th>
<th>Branch</th>
<th>Incharge</th>
<th>Date of registration</th>
<th>Status</th>
</tr>
<?php
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>
 <td><?php echo $row['id']; ?></td>
 <td><?php echo $row['Username']; ?></td>
 <td><?php echo $row['Issue']; ?></td>
 <td><?php echo $row['Branch']; ?></td>
 <td><?php echo $row['Incharge']; ?></td>
 <td><?php echo $row['date_of_registration']; ?></td>
 <td><?php echo $row['status']; ?></td>
 </tr>
 <?php
 }
}
else
{
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>
  