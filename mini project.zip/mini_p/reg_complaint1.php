<?php

   session_start();
?>
<html>
<head>
<title>
login form</title>
<style>
table{
border:none;
margin-top:130px;
color:#2E2E2E;
}
td,p{
font-size:30px;
color:#2E2E2E;
}
#but1{
font-size:30px;
width:100;
height:40;
background-color:#4B8A08;
color:white;
}
h1{
font-size:40px;
margin:30px;
color:#FF00BF;
text-decoration:underline;
}
.row{
height:30px;
width:200px;
border-radius:3px;
font-size:20px;
}
body{
background-image:url("bg9.jpg");
background-repeat:no-repeat;
background-attachment:fixed;
width:100%;
height:100%;
font-family:calibri;
font-size: 40px;
}
</style>
</head>
<body>
<center>
<h1>Register Here</h1>
<table border=0px cellspacing=0 cellpadding=0>
<form action="display_id1.php" method="post">
<tr>
<td>Username: </td>
<td><input type="text" name="uname" class="row" placeholder="Enter username"></td>
<tr><td>&nbsp;</td></tr>
<td>Mobile no: </td>
<td><input type="text" name="mobileno" class="row" placeholder="Enter mobile no."></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td>Hometown: </td>
<td><input type="text" name="address" class="row" placeholder="Enter your address"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td>Branch: </td>
<td class="row">
<input list="branch" name="branch" placeholder="Select a branch" class="row">
  <datalist id="branch">
    <option value="Karnataka">
    <option value="Kerala">
    <option value="Tamil Nadu">
    <option value="Bihar">
    <option value="Maharastra">
  </datalist>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td>Issue: </td>
<td >
<input list="complaint" name="complaint" placeholder="Select complaint" class="row">
  <datalist id="complaint">
    <option value="Product Issue">
    <option value="Payment Issue">
    <option value="Customer Service Issue">
    <option value="Delievery or Collection Issue">
    <option value="Product Warranty Issue">
  </datalist>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td colspan="2" rowspan="2" align="center"><button type="submit" name="submit" id="but1">submit</button></td>
</tr>
</form>
</center>
</body>
</html>