<?php
                 session_start();
$con=mysqli_connect('localhost','root','');
                 mysqli_select_db($con,'cms');                
$id = $_POST['cid'];
                 $status=$_POST['status'];  

$query = "update ocr3
                                  set status='$status'
                                  where id = '$id' ";

                  $result = mysqli_query($con, $query);

                 
   
                  

                 if($result ){
                      header("Location: update_success.html");
                 }else{
                  header("Location: update_ocr_wp1.php");
                 }

?>