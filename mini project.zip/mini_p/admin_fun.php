<?php
	$connect=new mysqli('localhost','root','','cms');
	if($connect->connect_error){
	echo("connection failed");
	}else
	{
		$sql="select date_of_registration from reg1";
		$result=$connect->query($sql);
		$c1=0;
		if ($result=mysqli_query($connect,$sql))
		{
			while ($row=mysqli_fetch_row($result))
			{
				$d=$row[0];
				$c1=$c1+1;
				$now = time();
				$your_date = strtotime($d);
				$datediff = $now - $your_date;
	
				echo round($datediff / (60 * 60 * 24))-1;
				
				$day=round($datediff / (60 * 60 * 24))-1;
				if($day >3&&$day<=5)
				$incharge="RCSE, BM";
				elseif($day>5&&$day<=7)
				$incharge="CSD - Head, AM";
				elseif($day>7)
				$incharge="AGM";
				$query = "UPDATE `reg1` SET `incharge`='".$incharge."' WHERE `id` = $c1";
   
			}
		}
		mysqli_free_result($result);
	}
?>
  