<?php
	$con=mysqli_connect('localhost','root','');
	if(!$con)
	{
	echo 'not connected';
	}
	if(!mysqli_select_db($con,'cms'))
	{
	echo 'database not selected';
	}
	$username=$_POST['uname'];
	$branch=$_POST['branch'];
	$issue=$_POST['complaint'];
	$status="pending";
	$incharge="CSE";
	$sql="INSERT INTO reg (username,issue,branch,incharge,date_of_registration,status) VALUES ('$username','$issue','$branch','$incharge',CURDATE(),'$status')";
	if(mysqli_query($con,$sql))
	{
		$id1=mysqli_insert_id($con);
		header("Location: uniq_id2.php");
	}
	else{
		echo "Not inserted";
	}
?>