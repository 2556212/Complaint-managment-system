<?php
$name="srilatha";
?>
<html>
<body>
<h1>Hello my name is <?php echo $name; ?></h1>
</body>
</html>