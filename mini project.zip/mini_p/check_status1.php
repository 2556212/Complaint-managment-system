<html>
<head>
<link rel="stylesheet" type="text/css" href="check_statuscss.css">
<style>
p{
	color:#2E2E2E;
	font-size:30px;
}
</style>
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
</center>
<div id="div2">
<div id="div3">
</div>
<div id="div4">
<center>
<div id="div5">
<p>Invalid complaint id, please try again!</p>
<form action="display_status.php" method="post">
<label id=l1>Complaint id: </label>
<input type="text" placeholder="Enter your complaint id" id="cid" name="cid"><br><br>
<button type="submit" id="getstatus">get status</button>
</form>
</div>
</center>
</div>
</div>
</body>
</html>