<?php
	$con=mysqli_connect('localhost','root','');
	if(!$con)
	{
	echo 'not connected';
	}
	if(!mysqli_select_db($con,'cms'))
	{
	echo 'database not selected';
	}
	$username=$_POST['uname'];
	$password=$_POST['pass'];
	$confirm=$_POST['confirm'];
	if($password!=$confirm)
	{
		header("Location:user_register1.php");
	}
	else
	{
	$sql="INSERT INTO user_login (username,password) VALUES ('$username','$password')";
	if(mysqli_query($con,$sql))
	{
		header("Location: reg_login.php");
	}
	else{
		header("Location: user_register1.php");
	}
	}
?>