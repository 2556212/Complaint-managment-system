<?php
	$connect=new mysqli('localhost','root','','cms');
	if($connect->connect_error){
	echo("connection failed");
	}else
	{
		$sql="select date_of_registration from smcr3";
		$result=$connect->query($sql);
		$count=0;
		if ($result=mysqli_query($connect,$sql))
		{
			while ($row=mysqli_fetch_row($result))
			{
				$d=$row[0];
				$incharge="OA, CSE/Sr CSE ";
				$count++;
				$now = time();
				$your_date = strtotime($d);
				$datediff = $now - $your_date;
				$day=round($datediff / (60 * 60 * 24))-1;
				if($day <= "3")
				$incharge="OA, CSE/Sr CSE ";
				else if($day > "3" && $day <= "5")
				$incharge="RCSE, BM";
				else if($day > "5" && $day <= "7")
				$incharge="CSD - Head, AM";
				else if($day > "7")
				$incharge="AGM";
				$sql3="select  status from smcr3 where id='$count'";
				$result3=$connect->query($sql3);
				$row1=mysqli_fetch_row($result3);
				$ans=$row1[0];
				}
				if($ans == "pending")
				{
				$query = "UPDATE `ocr3` SET `incharge`='".$incharge."' WHERE `id` = $count";
				$query1 = "UPDATE `smcr3` SET `incharge`='".$incharge."' WHERE `id` = $count";
				$result1 = mysqli_query($connect, $query);
				$result2= mysqli_query($connect,$query1);
				}
			}
			header("Location: escalate.html");
		}
		
	}
?>
  