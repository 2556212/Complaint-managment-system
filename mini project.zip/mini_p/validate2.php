<?php
	$connect=new mysqli('localhost','root','','cms');
	if($connect->connect_error){
	echo("connection failed");
	}else
	{
	$username= $_POST['uname'];
	$password= $_POST['pass'];
	$sql="select *from user_login where username='$username' and password='$password'";
	$result=$connect->query($sql);
	if($result->num_rows>0){
	while($row=$result->fetch_assoc()){
	header("Location: user_page.html");
	}	
	}
	else
	header("Location: user_login2.php");
	}
?>
  