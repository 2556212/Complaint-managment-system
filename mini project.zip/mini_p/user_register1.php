<html>
<head>
<title>
login form</title>
<style>
table{
border:none;
margin-top:130px;
color:#2E2E2E;
}
td,p{
font-size:30px;
color:#2E2E2E;
}
#but1{
font-size:30px;
width:100;
height:40;
background-color:#4B8A08;
color:white;
}
h1{
font-size:40px;
margin:30px;
color:#FF00BF;
text-decoration:underline;
}
.row{
height:30px;
width:200px;
border-radius:3px;
font-size:20px;
}
body{
background-image:url("bg9.jpg");
background-repeat:no-repeat;
background-attachment:fixed;
width:100%;
height:100%;
font-family:calibri;
font-size: 40px;
}
</style>
</head>
<body>
<center>
<h1>Register Here</h1>
<p>Failed to confirm the password!please try Again!</p>
<table border=0px cellspacing=0 cellpadding=0>
<form action="register_validate.php" method="post">
<tr>
<td>Username: </td>
<td><input type="text" name="uname" class="row" placeholder="Enter username"></td>
<tr><td>&nbsp;</td></tr>
<td>Password: </td>
<td><input type="password" name="pass" class="row" placeholder="Enter password"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td>Confirm password: </td>
<td><input type="password" name="confirm" class="row" placeholder="Enter password"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td colspan="2" rowspan="2" align="center"><button type="submit" name="submit" id="but1">submit</button></td>
</tr>
</form>
</center>
</body>
</html>