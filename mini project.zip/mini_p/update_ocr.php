<?php
                 session_start();
$con=mysqli_connect('localhost','root','');
                 mysqli_select_db($con,'cms');                
$id = $_POST['cid'];
                 $status=$_POST['status'];  



                  
                 $query1 = "update smcr3
                                    set status='$status'
                                    where id = '$id' ";
   
                  $result1 = mysqli_query($con,$query1);

                 if($result1){
                      header("Location: update_success.html");
                 }else{
                  header("Location: update_ocr_wp1.php");
                 }

?>