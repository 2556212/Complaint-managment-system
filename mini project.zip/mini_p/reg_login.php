<html>
<head>
<link rel="stylesheet" type="text/css" href="reg_login_css.css">
</head>
<body>
<center>
<div id="div1">
<img src="logo.jpg" id="logo">
Complaint managment system
</div>
</center>
<div id="div2">
<div id="div3">
</div>
<div id="div4">
<center>
<div id="div5">
You have registered successfully. <a href="user_login.php">Click Here</a> to login!
</div>
</center>
</div>
</div>
</body>
</html>