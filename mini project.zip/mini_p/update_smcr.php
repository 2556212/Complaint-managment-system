<?php
	$connect=new mysqli('localhost','root','','cms');
	if($connect->connect_error){
	echo("connection failed");
	}
	$id = $_POST['cid'];
	$sql="select  status from reg1 where id='$id'";
	$result=$connect->query($sql);
	if($result->num_rows==0){
		header("Location: update_ocr_wp1.php");
	}
	else{
     $status=$_POST['status'];   
	$query = "UPDATE `ocr3` SET `status`='".$status."' WHERE `id` = $id";
    $query1 = "UPDATE `smcr3` SET `status`='".$status."' WHERE `id` = $id";
   $result1 = mysqli_query($connect, $query);
   $result2 = mysqli_query($connect,$query1);
   if($result1)
   {
       header("Location: update_success.html");
   }else{
       header("Location: update_ocr_wp1.php");
   }
	}

?>