<?php
	$username= $_POST['uname'];
	$password= $_POST['pass'];
	if($username=="srilatha"&&$password=="cms")
	header("Location: admin.html");
	else
	header("Location: admin_login2.php");
?>
  